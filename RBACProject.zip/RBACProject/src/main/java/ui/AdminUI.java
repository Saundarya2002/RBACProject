package ui;

import service.UserService;

import javax.swing.*;

public class AdminUI {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;
    private UserService userService;

    public AdminUI(UserService userService) {
        this.userService = userService;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Admin Panel");
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(58, 81, 83, 16);
        frame.getContentPane().add(lblUsername);

        usernameField = new JTextField();
        usernameField.setBounds(153, 76, 130, 26);
        frame.getContentPane().add(usernameField);
        usernameField.setColumns(10);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(58, 119, 83, 16);
        frame.getContentPane().add(lblPassword);

        passwordField = new JPasswordField();
        passwordField.setBounds(153, 114, 130, 26);
        frame.getContentPane().add(passwordField);

        JLabel lblRole = new JLabel("Role:");
        lblRole.setBounds(58, 157, 83, 16);
        frame.getContentPane().add(lblRole);

        roleComboBox = new JComboBox<>(new String[]{"Admin", "Editor", "Viewer"});
        roleComboBox.setBounds(153, 152, 130, 26);
        frame.getContentPane().add(roleComboBox);

        JButton btnAddUser = new JButton("Add User");
        btnAddUser.setBounds(153, 190, 117, 29);
        frame.getContentPane().add(btnAddUser);

        btnAddUser.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String role = (String) roleComboBox.getSelectedItem();
            int roleId = role.equals("Admin") ? 1 : role.equals("Editor") ? 2 : 3;
            userService.registerUser(username, password, roleId);
            JOptionPane.showMessageDialog(frame, "User added successfully!");
        });
    }

    public void show() {
        frame.setVisible(true);
    }
}
