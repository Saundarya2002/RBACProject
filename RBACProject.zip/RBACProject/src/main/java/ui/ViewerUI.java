package ui;

import javax.swing.*;

public class ViewerUI {
    private JFrame frame;

    public ViewerUI() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Viewer Panel");
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblMessage = new JLabel("Welcome, Viewer!");
        lblMessage.setBounds(58, 81, 200, 16);
        frame.getContentPane().add(lblMessage);
    }

    public void show() {
        frame.setVisible(true);
    }
}
