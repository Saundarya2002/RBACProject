package ui;

import service.UserService;
import Utils.JWT;

import javax.swing.*;

public class LoginUI {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private UserService userService;

    public LoginUI(UserService userService) {
        this.userService = userService;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Login");
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(58, 81, 83, 16);
        frame.getContentPane().add(lblUsername);

        usernameField = new JTextField();
        usernameField.setBounds(153, 76, 130, 26);
        frame.getContentPane().add(usernameField);
        usernameField.setColumns(10);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setBounds(58, 119, 83, 16);
        frame.getContentPane().add(lblPassword);

        passwordField = new JPasswordField();
        passwordField.setBounds(153, 114, 130, 26);
        frame.getContentPane().add(passwordField);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBounds(153, 152, 117, 29);
        frame.getContentPane().add(btnLogin);

        btnLogin.addActionListener(e -> {
            String username = usernameField.getText();

            String password = new String(passwordField.getPassword());

            String token = userService.authenticateUser(username, password);
            if (token != null) {
                String role = JWT.validateToken(token).get("role", String.class);
                switch (role) {
                    case "Admin":
                        new AdminUI(userService).show();
                        break;
                    case "Editor":
                        new EditorUI().show();
                        break;
                    case "Viewer":
                        new ViewerUI().show();
                        break;
                    default:
                        JOptionPane.showMessageDialog(frame, "Invalid role");
                }
                frame.setVisible(false);
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid username or password");
            }
        });
    }

    public void show() {
        frame.setVisible(true);
    }
}
