package ui;

import javax.swing.*;

public class EditorUI {
    private JFrame frame;

    public EditorUI() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Editor Panel");
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JLabel lblMessage = new JLabel("Welcome, Editor!");
        lblMessage.setBounds(58, 81, 200, 16);
        frame.getContentPane().add(lblMessage);
    }

    public void show() {
        frame.setVisible(true);
    }
}
