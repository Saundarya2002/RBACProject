package org.example;

import Database.Database;
import service.UserService;
import ui.LoginUI;

public class Main {
    public static void main(String[] args) {
        Database.initializeDatabase();
        UserService userService = new UserService();
        new LoginUI(userService).show();
    }
}
