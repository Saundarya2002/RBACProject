package service;

import org.mindrot.jbcrypt.BCrypt;
import Utils.JWT;
import Database.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserService {
    public void registerUser(String username, String password, int roleId) {
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        try (Connection conn = Database.getConnection()) {
            String sql = "INSERT INTO users (username, password, role_id) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, hashedPassword);
                stmt.setInt(3, roleId);
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String authenticateUser(String username, String password) {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT password, role_id FROM users WHERE username = ?";
            System.out.println("userservice");
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                try (ResultSet rs = stmt.executeQuery()) {

                    if (rs.next()) {
                        String sysPassword = rs.getString("password");
                        int roleId = rs.getInt("role_id");

                        if (BCrypt.checkpw(password,sysPassword)) {

                            String role = getRoleName(roleId);
                            return JWT.generateToken(username, role);
                        }
                    }
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public String getRoleName(int roleId) {
        switch (roleId) {
            case 1:
                return "Admin";
            case 2:
                return "Editor";
            case 3:
                return "Viewer";
            default:
                return "Unknown";
        }
    }

    public int getUserRole(String username) {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT role_id FROM users WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt("role_id");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
