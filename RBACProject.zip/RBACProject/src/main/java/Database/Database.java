package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
    private static final String URL = "jdbc:h2:~/rbacdb";
    private static final String USER = "sa";
    private static final String PASSWORD = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void initializeDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            String sql = "CREATE TABLE IF NOT EXISTS users (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "username VARCHAR(255) NOT NULL," +
                    "password VARCHAR(255) NOT NULL," +
                    "role_id INT NOT NULL)";
            String recordsSql="INSERT INTO users (username, password, role_id) VALUES" +
                    "('admin', '$2a$10$D1QF6V7xOexkL/7KYBO3eO0Hd/Sz9L4QjWz8yJf7heG45Eo/tg4aG', 1)," +
                    "('editor', '$2a$10$GnjsyQ0O5Gfhe1Ex.PFsdO0uyg9PTOQMGZTnznT4dJ6xJtCJ2D.M2', 2)," +
                    "('viewer', '$2a$10$KXhJ9dsD5MyfRI4/KZnSWejGzPh1zZfb1dQzFteHl4RA3bc/4.UuC', 3); ";
            stmt.execute(sql);
            stmt.execute(recordsSql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
